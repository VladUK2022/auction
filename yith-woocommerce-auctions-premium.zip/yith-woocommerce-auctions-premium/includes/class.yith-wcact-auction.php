<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( ! defined( 'YITH_WCACT_VERSION' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 * Main Class YITH_Auctions
 *
 * @class      YITH_AUCTIONS
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     Your Inspiration Themes
 */

if ( ! class_exists( 'YITH_Auctions' ) ) {
	/**
	 * Class YITH_AUCTIONS
	 *
	 * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
	 */
	class YITH_Auctions {
		/**
		 * Plugin version
		 *
		 * @var string
		 * @since 1.0
		 */
		public $version = YITH_WCACT_VERSION;
		/**
		 * Main Instance
		 *
		 * @var YITH_Auctions
		 * @since 1.0
		 * @access protected
		 */
		protected static $_instance = null;
		/**
		 * Main Admin Instance
		 *
		 * @var YITH_Auction_Admin
		 * @since 1.0
		 */
		public $admin = null;
		/**
		 * Main Frontpage Instance
		 *
		 * @var YITH_Auction_Frontend
		 * @since 1.0
		 */
		public $frontend = null;
		/**
		 * Main Product Instance
		 *
		 * @var WC_Product_Auction
		 * @since 1.0
		 */
		public $product = null;
		/**
		 * Construct
		 *
		 * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
		 * @since 1.0
		 */
		public function __construct() {
			/* === Require Main Files === */
			$require = apply_filters('yith_wcact_require_class',
				 array(
					'common'   => array(
						'includes/legacy/abstract.yith-wcact-legacy-auction-product.php',
						'includes/class.yith-wcact-auction-product.php',
						'includes/class.yith-wcact-auction-db.php',
						'includes/class.yith-wcact-auction-bids.php',
						'includes/class.yith-wcact-auction-ajax.php',
						'includes/class.yith-wcact-auction-my-auctions.php',
						'includes/class.yith-wcact-auction-finish-auction.php',
						'includes/compatibility/class.yith-wcact-compatibility.php',
					),
					'admin' => array(
						'includes/class.yith-wcact-auction-admin.php',
					),
					'frontend' => array(
						'includes/class.yith-wcact-auction-frontend.php',
					),
				)
			);

            $this->_require($require);

            $this->init_classes();

            /* === Load Plugin Framework === */
            add_action('plugins_loaded', array($this, 'plugin_fw_loader'), 15);

            /* === Register data store for Auction Products === */
            add_filter( 'woocommerce_data_stores', array( $this, 'register_data_stores' ) );

			/* Register plugin to licence/update system */
			add_action('wp_loaded', array($this, 'register_plugin_for_activation'), 99);
			add_action('admin_init', array($this, 'register_plugin_for_updates'));

            $this->__set_init_values_for_2_0_version();
            /* == Plugins Init === */
            $this->init();

        }

        /**
         * Main plugin Instance
         *
         * @return YITH_Auctions Main instance
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         */
        public static function instance()
        {
            $self = __CLASS__ . ( class_exists( __CLASS__ . '_Premium' ) ? '_Premium' : '' );

            if ( is_null( $self::$_instance ) ) {
                $self::$_instance = new $self;
            }

            return $self::$_instance;
        }


        public function init_classes(){
            $this->bids = YITH_WCACT_Bids::get_instance();
            $this->ajax = YITH_WCACT_Auction_Ajax::get_instance();
            $this->compatibility = YITH_WCACT_Compatibility::get_instance();
        }

        /**
         * Add the main classes file
         *
         * Include the admin and frontend classes
         *
         * @param $main_classes array The require classes file path
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since  1.0
         *
         * @return void
         * @access protected
         */
        protected function _require($main_classes)
        {
            foreach ($main_classes as $section => $classes) {
                foreach ($classes as $class) {
                    if ('common' == $section || ('frontend' == $section && !is_admin() || (defined('DOING_AJAX') && DOING_AJAX)) || ('admin' == $section && is_admin()) && file_exists(YITH_WCACT_PATH . $class)) {
                        require_once(YITH_WCACT_PATH . $class);
                    }
                }
            }
        }

        /**
         * Load plugin framework
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since  1.0
         * @return void
         */
        public function plugin_fw_loader()
        {
            if (!defined('YIT_CORE_PLUGIN')) {
                global $plugin_fw_data;
                if (!empty($plugin_fw_data)) {
                    $plugin_fw_file = array_shift($plugin_fw_data);
                    require_once($plugin_fw_file);
                }
            }
        }

        /**
         * Register data stores for bookings.
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since  1.3.4
         * @param  array  $data_stores
         * @return array
         */
        public function register_data_stores( $data_stores = array() ) {
            $data_stores['product-auction'] = 'YITH_WCACT_Product_Auction_Data_Store_CPT';
            return $data_stores;
        }

        /**
         * Function init()
         *
         * Instance the admin or frontend classes
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since  1.0
         * @return void
         * @access protected
         */
        public function init()
        {
            if (is_admin()) {
                $this->admin =  YITH_Auction_Admin::get_instance();
            }

            if (!is_admin() || (defined('DOING_AJAX') && DOING_AJAX)) {
                $this->frontend = YITH_Auction_Frontend::get_instance();
            }
        }
	    /**
	     * Function __set_init_values_for_2_0_version()
	     *
	     * Set old values on new options
	     *
	     * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
	     * @since  2.0
	     * @return void
	     * @access protected
	     */
        protected function __set_init_values_for_2_0_version() {

	        $already_processed = get_option( 'yith_wcact_set_values_2_0', false );

	        if ( $already_processed ) {
		        return;
	        }
	         $old_date_format = get_option( 'yith_wcact_settings_date_format' ); //It should not be removed

	        if( $old_date_format ) {
		        $new_format = explode(" ", $old_date_format);
				if( 2 == count($new_format) ) {
					update_option( 'yith_wcact_general_date_format', $new_format[0] );
					update_option( 'yith_wcact_general_time_format', $new_format[1] );
				}

	        }

	    //Reschedule auction ended without bids general option.
	        $reschedule_number = get_option('yith_wcact_settings_automatic_reschedule_auctions_number',0);

	        if( $reschedule_number && $reschedule_number > 0 ) {
	        	update_option('yith_wcact_settings_reschedule_auctions_without_bids','yes');
	        }


	        update_option( 'yith_wcact_set_values_2_0', true );

        }

		/**
		 * Register plugins for activation tab
		 *
		 * @return void
		 * @since    2.0.0
		 * @author   Andrea Grillo <andrea.grillo@yithemes.com>
		 */
		public function register_plugin_for_activation()
		{
			if (!class_exists('YIT_Plugin_Licence')) {
				require_once YITH_WCACT_PATH . '/plugin-fw/licence/lib/yit-licence.php';
				require_once YITH_WCACT_PATH . '/plugin-fw/licence/lib/yit-plugin-licence.php';
			}
			YIT_Plugin_Licence()->register(YITH_WCACT_INIT, YITH_WCACT_SECRETKEY, YITH_WCACT_SLUG);

		}

		/**
		 * Register plugins for update tab
		 *
		 * @return void
		 * @since    2.0.0
		 * @author   Andrea Grillo <andrea.grillo@yithemes.com>
		 */
		public function register_plugin_for_updates()
		{
			if (!class_exists('YIT_Upgrade')) {
				require_once(YITH_WCACT_PATH . '/plugin-fw/lib/yit-upgrade.php');
			}
			YIT_Upgrade()->register(YITH_WCACT_SLUG, YITH_WCACT_INIT);
		}
    }
}
