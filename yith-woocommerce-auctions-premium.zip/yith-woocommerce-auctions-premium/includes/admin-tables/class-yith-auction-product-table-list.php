<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 **/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'YITH_Auction_Product_List_Table' ) ) {


	class YITH_Auction_Product_List_Table extends WP_List_Table {

		/**
		 * Construct
		 * @param  array $args
		 * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
		 * @since 2.0
		 */

		public $bids;

		public function __construct( $args = array() ) {
			parent::__construct(
				array(
					'singular' => esc_html__( 'Auction List', 'yith-auctions-for-woocommerce' ),
					'plural'   => esc_html__( 'Auctions Tables', 'yith-auctions-for-woocommerce' ),
					'ajax'     => false,
				)
			);

			$this->bids = YITH_Auctions()->bids;

		}

		/**
		 * Return the columns for the table
		 * @return array
		 * @since 2.1.0
		 * @author YITH
		 */
		public function get_columns() {


			$columns = array(
				'auction'       => esc_html__( 'Auction', 'yith-auctions-for-woocommerce' ),
				'started_on'    => esc_html__( 'Started on', 'yith-auctions-for-woocommerce' ),
				'start_price'   => esc_html__( 'Start price', 'yith-auctions-for-woocommerce' ),
				'current_bid'   => esc_html__( 'Current bid', 'yith-auctions-for-woocommerce' ),
				'bids'          => esc_html__( 'Bids', 'yith-auctions-for-woocommerce' ),
				'bidders'       => esc_html__( 'Bidders', 'yith-auctions-for-woocommerce' ),
				'followers'     => esc_html__( 'Followers', 'yith-auctions-for-woocommerce' ),
				'watchers'      => esc_html__( 'Watchers', 'yith-auctions-for-woocommerce' ),
				'reserve_price' => esc_html__( 'Reserve price', 'yith-auctions-for-woocommerce' ),
				'end_on'        => esc_html__( 'End on:', 'yith-auctions-for-woocommerce' ),
				'status'        => esc_html__( 'Status:', 'yith-auctions-for-woocommerce' ),
			);

			return apply_filters('yith_wcact_auction_list_columns', $columns );
		}


		/**
		 * Column Default
		 * @param object|int $product
		 * @param string $column_name
		 */
		public function column_default( $product, $column_name ) {
			$output = '';
			switch ( $column_name ) {

				case 'started_on':

					$format_date = get_option( 'yith_wcact_general_date_format', 'j/n/Y' );
					$format_time = get_option( 'yith_wcact_general_time_format', 'h:i:s' );

					$format = $format_date . ' ' . $format_time;

					$output = get_date_from_gmt( date( 'Y-m-d H:i:s', $product->get_start_date() ), $format );
					break;
				case 'start_price':
					$output = wc_price( $product->get_start_price() );

					break;

				case 'current_bid':

					$output = wc_price( $product->get_current_bid() );

					break;

				case 'bids' :

					$bids = $this->bids->get_bids_auction( $product->get_id() );

					if ( $bids && is_array( $bids ) && ! empty( $bids ) ) {
						$bids_value = count( $bids );
					} else {
						$bids_value = 0;
					}

					$output = $bids_value;

					break;
				case 'bidders' :

					$users = $this->bids->get_bidders( $product->get_id() );

					if ( $users && is_array( $users ) && ! empty( $users ) ) {

						$output = count( $users );

					} else {

						$output = esc_html__( 'No bidders', 'yith-auctions-for-woocommerce' );

					}


					break;

				case 'followers' :

					$followers = yit_get_prop( $product, 'yith_wcact_auction_watchlist', true );

					if ( $followers && is_array( $followers ) && ! empty( $followers ) ) {
						$output = count( $followers );
					} else {
						$output = esc_html__( 'No followers', 'yith-auctions-for-woocommerce' );
					}

					break;

				case 'watchers' :
					$users_watchlist = $this->bids->get_users_count_product_on_watchlist( $product->get_id() );
					if ( is_array( $users_watchlist ) && ! empty( $users_watchlist ) ) {
						$output = count( $users_watchlist );
					} else {
						$output = esc_html__( 'No watchers', 'yith-auctions-for-woocommerce' );
					}

					break;

				case 'reserve_price' :

					$reserve_price = $product->get_reserve_price();

					if ( $reserve_price > 0 ) {
						$price = $product->get_price();
						if ( $price > $reserve_price ) {
							$output = "<span class='yith-wcact-reserve-price-passed'>" . wc_price( $reserve_price ) . " (&#10003)" . "</span>";
						} else {
							$output = wc_price( $reserve_price );
						}
					} else {
						$output = esc_html__( 'No reserve price', 'yith-auctions-for-woocommerce' );

					}


					break;

				case 'end_on' :

					$end_date = $product->get_end_date();
					$time_now = time();

					if ( $end_date > $time_now ) {
						$format_date = get_option( 'yith_wcact_general_date_format', 'j/n/Y' );
						$format_time = get_option( 'yith_wcact_general_time_format', 'h:i:s' );
						$format      = $format_date . ' ' . $format_time;

						$output = get_date_from_gmt( date( 'Y-m-d H:i:s', $product->get_end_date() ), $format );
					} else {
						$output = esc_html__( 'Ended', 'yith-auctions-for-woocommerce' );
					}


					break;
				case 'status' :
					$product_status = $product->get_status();

					if ( 'draft' === $product_status ) {
						$output = esc_html( 'Draft', 'yith-auctions-for-woocommerce' );
					} else {
						$type = $product->get_auction_status();
						switch ( $type ) {
							case 'non-started' :
								$output = '<span class="yith-wcact-auction-status yith-auction-non-start tips" data-tip="' . esc_attr__( 'Not Started', 'yith-auctions-for-woocommerce' ) . '"></span>';
								break;
							case 'started' :
								$output = '<span class="yith-wcact-auction-status yith-auction-started tips" data-tip="' . esc_attr__( 'Started', 'yith-auctions-for-woocommerce' ) . '"></span>';
								break;
							case 'finished' :
								$output = '<span class="yith-wcact-auction-status yith-auction-finished tips" data-tip="' . esc_attr__( 'Finished', 'yith-auctions-for-woocommerce' ) . '"></span>';
								break;
							case 'started-reached-reserve' :
								$output = '<span class="yith-wcact-auction-status yith-auction-started-reached-reserve tips" data-tip="' . esc_attr__( 'Started and not exceeded the reserve price', 'yith-auctions-for-woocommerce' ) . '">';
								break;
							case 'finished-reached-reserve' :
								$output = '<span class="yith-wcact-auction-status yith-auction-finished-reached-reserve tips" data-tip="' . esc_attr__( 'Finished and not exceeded the reserve price', 'yith-auctions-for-woocommerce' ) . '"></span>';
								break;
							case 'finnish-buy-now' :
								$output = '<span class="yith-wcact-auction-status yith-auction-finnish-buy-now tips" data-tip="' . esc_attr__( 'Purchased through buy now', 'yith-auctions-for-woocommerce' ) . '"></span>';
								break;
						}
					}
			}

			echo  apply_filters('yith_wcact_auction_list_output_column', $output, $column_name, $product ); ;
		}

		/**
		 * Column Auction
		 * @param object|int $product
		 */
		public function column_auction( $product ) {
			$edit_link = get_edit_post_link( $product->get_id() );
			$title     = $product->get_title();

			$product_status = $product->get_status();

			$output = '<strong><a class="row-title" href="' . esc_url( $edit_link ) . '">' . esc_html( $title ) . '</a>';
			$output .= ( 'draft' == $product_status ? ' - ' . ucfirst( $product_status ) : '' );
			$output .= '</strong>';


			return $output;
		}
		/**
		 * Prepares the list of items for displaying.
		 *
		 * @uses WP_List_Table::set_pagination_args()
		 *
		 * @since 1.0.0
		 */
		public function prepare_items() {

			if ( ! empty( $_REQUEST['_wp_http_referer'] ) ) {
				// _wp_http_referer is used only on bulk actions, we remove it to keep the $_GET shorter
				wp_redirect( remove_query_arg( array( '_wp_http_referer', '_wpnonce' ), wp_unslash( $_SERVER['REQUEST_URI'] ) ) );
				exit;
			}

			$per_page              = 15;
			$columns               = $this->get_columns();
			$hidden                = array();
			$sortable              = $this->get_sortable_columns();
			$this->_column_headers = array( $columns, $hidden, $sortable );
			$this->_column_headers = array( $columns, $hidden );

			$current_page = $this->get_pagenum();

			$query_args = array();

			$auction_type        = isset( $_REQUEST['auction_type'] ) ? $_REQUEST['auction_type'] : '';

			if( !empty( $auction_type ) ) {
				$query_args['ywcact_auction_type'] = $auction_type;
			}

			if ( isset( $_GET['status'] ) && 'all' != $_GET['status'] ) {
				$query_args['status'] = $_GET['status'];
			}
			$items      = wc_get_products( array_merge( array(
															'type'   => 'auction',
															'limit'  => $per_page,
															'offset' => ( ( $current_page - 1 ) * $per_page ),
														)
										   , $query_args ) );

			$total_items = count( wc_get_products( array('type'=>'auction','limit' => -1) ) );

			$this->set_pagination_args(
				array(
					'total_items' => $total_items,
					'per_page'    => $per_page,
					'total_pages' => ceil( $total_items / $per_page ),
				)
			);

			$this->items = $items;

		}
		/**
		 * Generates the tbody element for the list table.
		 *
		 * @since 3.1.0
		 */
		public function display_rows_or_placeholder() {
			if ( $this->has_items() ) {
				$this->display_rows();
			} else {
				echo '<tr class="no-items"><td class="colspanchange" colspan="' . $this->get_column_count() . '">';
				$this->no_items();
				echo '</td></tr>';
			}
		}


		/**
		 * get views for the table
		 * @return array
		 * @since 1.0.0
		 * @author YITHEMES
		 */
		protected function get_views() {
			$views = array(
				'all'     => __( 'All', 'yith-auctions-for-woocommerce' ),
				/*'publish' => __( 'Published', 'yith-auctions-for-woocommerce' ),
				'mine'    => __( 'Mine', 'yith-auctions-for-woocommerce' ),*/
				'draft'   => __( 'Draft', 'yith-auctions-for-woocommerce' ),
				'trash'   => __( 'Trash', 'yith-auctions-for-woocommerce' ),
			);

			$current_view = $this->get_current_view();

			foreach ( $views as $view_id => $view ) {

				$query_args = array(
					'posts_per_page'  => - 1,
					'post_type'       => 'product',
					'post_status'     => array('publish','draft'),
					'suppress_filter' => false,
					'tax_query' => array(
						array(
							'taxonomy' => 'product_type',
							'field'    => 'slug',
							'terms'    => 'auction',
						),
					),
				);


				$status                   = 'status';
				$id                       = $view_id;

				if ( 'all' !== $view_id ) {
					$query_args['post_status'] = $view_id;
				}

				$href              = esc_url( add_query_arg( $status, $id ) );
				$total_items       = count( get_posts( $query_args ) );
				if( $total_items > 0  ) {
					$class             = $view_id == $current_view ? 'current' : '';
					$views[ $view_id ] = sprintf( "<a href='%s' class='%s'>%s <span class='count'>(%d)</span></a>", $href, $class, $view, $total_items );
				} else {
					unset( $views[ $view_id] );
				}
			}


			return $views;
		}

		/**
		 * Extra controls to be displayed between bulk actions and pagination.
		 *
		 * @param string $which
		 */
		protected function extra_tablenav( $which ) {

			if ( $which != 'top' ) {
				return;
			}

			$filter_options = apply_filters( 'yith_wcact_auction_list_filter_status', array(

					'all'            => esc_html__('Show all auction statuses', 'yith-auctions-for-woocommerce'),
					'non-started' => esc_html__('Not Started', 'yith-auctions-for-woocommerce'),
					'started'	  => esc_html__('Started', 'yith-auctions-for-woocommerce'),
					'finished'    => esc_html__('Finished', 'yith-auctions-for-woocommerce'),
				)
			);

			$auction_type        = isset( $_REQUEST['auction_type'] ) ? $_REQUEST['auction_type'] : '';

				echo '<div class="alignleft actions">';

					yith_wcact_get_dropdown(array(
						'name'      => 'auction_type',
						'id'        => 'dropdown_auction_type',
						'class'     => '',
						'options'   => $filter_options,
						'value'     => $auction_type,
						'echo'		=> true,
					));

					submit_button( esc_html__( 'Filter', 'woocommerce' ), 'button', 'filter_action', false, array( 'id' => 'post-query-submit' ) );
				echo '</div>';

				submit_button( __( 'Export CSV', 'yith-woocommerce-affiliates' ), 'button', 'export_action', false );

		}


		/**
		 * return current view
		 * @return string
		 * @since 1.0.0
		 * @author YITHEMES
		 */
		public function get_current_view() {

			return empty( $_GET['status'] ) ? 'all' : $_GET['status'];
		}
	}
}

