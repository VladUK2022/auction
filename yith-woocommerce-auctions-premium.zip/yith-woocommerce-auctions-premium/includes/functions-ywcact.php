<?php
/**
 * Custom functions
 *
 * @author YITH
 * @package YITH Auctions for WooCommerce
 * @version 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly


if ( ! function_exists( 'yith_wcact_product_metabox_form_field' ) ) {
	/**
	 * print a form field for product metabox
	 *
	 * @since 2.0.0
	 */
	function yith_wcact_product_metabox_form_field( $field ) {

		$defaults = array(
			'class'     => '',
			'title'     => '',
			'label_for' => '',
			'desc'      => '',
			'data'      => array(),
			'fields'    => array(),
		);
		$field    = apply_filters( 'yith_wcact_product_metabox_form_field_args', wp_parse_args( $field, $defaults ), $field);
		/**
		 * @var string $class
		 * @var string $title
		 * @var string $label_for
		 * @var string $desc
		 * @var array  $data
		 * @var array  $fields
		 */
		extract( $field );

		if ( ! $label_for && $fields ) {
			$first_field = current( $fields );
			if ( isset( $first_field['id'] ) ) {
				$label_for = $first_field['id'];
			}
		}

		$data_html = '';
		foreach ( $data as $key => $value ) {
			$data_html .= "data-{$key}='{$value}' ";
		}

		$html = '';
		$html .= "<div class='yith-wcact-form-field {$class}' {$data_html}>";
		$html .= "<label class='yith-wcact-form-field__label' for='{$label_for}'>{$title}</label>";

		$html .= "<div class='yith-wcact-form-field__container'>";
		ob_start();
		yith_plugin_fw_get_field( $fields, true ); //Print field using plugin-fw
		$html .= ob_get_clean();
		$html .= "</div><!-- yith-wcact-form-field__container -->";

		if ( $desc ) {
			$html .= "<div class='yith-wcact-form-field__description'>{$desc}</div>";
		}

		$html .= "</div><!-- yith-wcact-form-field -->";

		echo  apply_filters( 'yith_wcact_product_metabox_form_field_html', $html, $field );
	}
}

if ( !function_exists('yith_wcact_field_onoff_value' ) ) {
	/**
	 * Check for onoff fields where the fields associated are set before 2.0 version
	 *
	 * @param string     $field
	 * @param string     $dependency
	 * @param WC_Product $product
	 * @return string    $position
	 * @since 2.0.0
	 */
	function yith_wcact_field_onoff_value( $field, $dependency, $product ) {

		$position = 'no';

		$value = $product->{"get_$field"}();

		if ( $value ) {

			$position = 'yes' == $value ? 'yes' : 'no';

		} else {
			$value_son = $product->{"get_$dependency"}();

			if ( isset( $value_son ) && $value_son > 0 ) {

				$position = 'yes';
			}
		}

		return apply_filters( 'yith_wcact_field_onoff_value_filter', $position, $field, $dependency, $product, $value );
	}
}

if ( !function_exists('yith_wcact_field_radio_value' ) ) {
	/**
	 * Check for radio fields where the fields associated are set before 2.0 version
	 *
	 * @param string $field
	 * @param string $dependency
	 * @param WC_Product $product
	 * @param string $default_value
	 * @return string $position
	 * @since 2.0.0
	 */
	function yith_wcact_field_radio_value( $field, $dependency, $product, $default_value = '', $dependecy_value = '' ) {

		$position = isset( $default_value ) && $default_value ? $default_value : '';

		$value = $product->{"get_$field"}();

		if ( $value ) {

			$position = $value;

		} else {
			$value_son = $product->{"get_$dependency"}();
			if ( isset( $value_son ) && $value_son ) {
				$position = $dependecy_value;
			}
		}

		return $position;
	}
}

if ( !function_exists('yith_wcact_get_select_time_values' ) ) {
	/**
	 * Check for radio fields where the fields associated are set before 2.0 version
	 * @return array $values
	 * @since 2.0.0
	 */
	function yith_wcact_get_select_time_values() {

		$values = array(
			'days'    => esc_html_x( 'days', 'Admin option: days', 'yith-auctions-for-woocommerce' ),
			'hours'   => esc_html_x( 'hours', 'Admin option: hours', 'yith-auctions-for-woocommerce' ),
			'minutes' => esc_html_x( 'minutes', 'Admin option: hours', 'yith-auctions-for-woocommerce' ),
		);
		return $values;
	}
}

if ( ! function_exists( 'yith_wcact_get_current_url' ) ) {
	/**
	 * Retrieves current url
	 *
	 * @return string Current url
	 * @since 2.0.0
	 */
	function yith_wcact_get_current_url() {
		global $wp;

		return add_query_arg( $wp->query_vars, home_url( $wp->request ) );
	}
}

if ( ! function_exists( 'yith_wcact_get_watchlist_url' ) ) {
	/**
	 * Retrieves watchlist url
	 *
	 * @return string watchlist url
	 * @since 2.0.0
	 */
	function yith_wcact_get_watchlist_url() {

		$my_auction_url = wc_get_endpoint_url( 'my-auction', '', wc_get_page_permalink( 'myaccount' ) );
		$watchlist_url  = add_query_arg( 'my-auction', 'watchlist', $my_auction_url );
		return $watchlist_url;
	}
}


if ( ! function_exists( 'yith_wcact_get_payment_method_url' ) ) {
	/**
	 * Retrieves payment method url
	 *
	 * @return string watchlist url
	 * @since 2.0.0
	 */
	function yith_wcact_get_payment_method_url() {

		$payment_method_url = wc_get_endpoint_url( 'payment-methods', '', wc_get_page_permalink( 'myaccount' ) );
		return $payment_method_url;
	}
}
if ( ! function_exists( 'yith_wcact_get_dropdown' ) ) {

	function yith_wcact_get_dropdown( $args = array() ) {
		$default_args = array(
			'id'       => '',
			'name'     => '',
			'class'    => '',
			'style'    => '',
			'options'  => array(),
			'value'    => '',
			'disabled' => '',
			'multiple' => '',
			'echo'     => false
		);

		$args = wp_parse_args( $args, $default_args );
		extract( $args );
		/**
		 * @var string $id
		 * @var string $name
		 * @var string $class
		 * @var string $style
		 * @var array  $options
		 * @var string $value
		 * @var bool   $echo
		 * @var string $disabled
		 */
		$html = "<select id='$id' name='$name' class='$class' $multiple style='$style'>";

		foreach ( $options as $option_key => $option_label ) {
			$selected = selected( $option_key == $value, true, false );
			$disabled = disabled( $option_key == $disabled, true, false );
			$html     .= "<option value='$option_key' $selected $disabled >$option_label</option>";
		}

		$html .= "</select>";

		if ( $echo ) {
			echo $html;
		} else {
			return $html;
		}
	}
}

if ( ! function_exists( 'yith_wcact_auction_message' ) ) {

	/**
	 * Retrieves Auction message for ajax call
	 *
	 * @return string $message
	 *
	 * @since 2.0.0
	 */

	function yith_wcact_auction_message( $type, $product ='false' ) {

		$message = '';

			switch ( $type ) {
				case 0 :
					$message =  esc_html__('You have successfully bid', 'yith-auctions-for-woocommerce');
					break;

				case 1:
					$message = $product && 'yes' == $product->get_auction_sealed() ? esc_html__( 'Error: there is a lower current bid for this auction. Try with a new offer', 'yith-auctions-for-woocommerce' )  : esc_html__('Enter %s or less to be able to bid', 'yith-auctions-for-woocommerce');
					break;

				case 2:
					$message = esc_html__('Please enter a valid bid. Negative bid are not available', 'yith-auctions-for-woocommerce');
					break;

				case 3:
					$message = esc_html__('You have successfully bid but there is a higher current bid for this auction. Try with a new offer', 'yith-auctions-for-woocommerce');
					break;

				case 4:
					$message = $product && 'yes' == $product->get_auction_sealed() ? esc_html__( 'Error: there is a higher current bid for this auction. Try with a new offer', 'yith-auctions-for-woocommerce' )  : esc_html__('Enter %s or more to be able to bid', 'yith-auctions-for-woocommerce');
					break;
				case 5:
					$message = esc_html__('You have successfully bid but there is a lower current bid for this auction. Try with a new offer', 'yith-auctions-for-woocommerce');
					break;
			}



		return apply_filters('yith_wcact_auction_message_response', $message, $type, $product );
	}

}


if ( ! function_exists( 'yith_wcact_auction_compare_bids' ) ) {
	/**
	 * Compare two values with operator
	 *
	 * @return string $message
	 *
	 * @since 2.0.0
	 */
	function yith_wcact_auction_compare_bids( $first_value, $operator, $second_value ) {
		$value = false;
		switch ( $operator ) {
			case '>' :
				$value = ( $first_value > $second_value );
				break;
			case '<' :
				$value = ( $first_value < $second_value );
				break;
		}
		return $value;

	}
}