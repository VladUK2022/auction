<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

$price_format = sprintf( get_woocommerce_price_format(), '<span class="ywcact-bid-popup-symbol">'. get_woocommerce_currency_symbol().'</span>', '<span class="ywcact-bid-popup-value"></span>' );

?>

<span class="yith-wcact-confirmation-bid yith-wcact-popup-button" data-ywcact-content-id=".yith-wcact-ask-confirmation-modal"></span>

<div class="yith-wcact-ask-confirmation-modal"
     style="display: none">
    <div class="yith-wcact-modal-title">

        <h3><?php echo sprintf( __( "You are bidding %s for this auction.", 'yith-auctions-for-woocommerce' ), $price_format ) ?></h3>
    </div>
    <div class="yith-wcact-modal-content">
        <p><?php echo apply_filters('yith_wcact_confirmation_popup_message_before', esc_html__('it\'s great!','yith-auctions-for-woocommerce') );?></p>
        <p>
            <?php echo apply_filters('yith_wcact_confirmation_popup_message_after', esc_html__( "Remember, a bid is considered a binding contract. That means that if you bid on this item, you are committing to buy it if you win.",
	            'yith-auctions-for-woocommerce' ) )  ?>
        </p>
    </div>
    <div class="yith-wcact-modal-buttons">
        <button type="button" class="button alt ywcact-modal-button ywcact-modal-button-confirm-bid" ><?php esc_html_e('Yes, I want to bid', 'yith-auctions-for-woocommerce'); ?></button>
    </div>
</div>