<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

$instance = YITH_Auctions()->bids;
$user_id  = get_current_user_id();
$date     = date( 'Y-m-d H:i:s' );

$limit = apply_filters( 'yith_wcact_my_account_table_limit', 3 );


$auctions_by_user = $instance->get_auctions_by_user( $user_id );

?>
<div>
	<input class="ywcact-my-acount-auction-template" data-type="auction-index" type="hidden">
	<div class="yith-wcact-my-auctions-list-index-container">
		<div class="yith-wcact-my-auctions-list-index-container-header">
			<h3><?php esc_html_e( 'My auctions', 'yith-auctions-for-woocommerce' ); ?></h3>
		</div>
		<div class="yith-wcact-my-auctions-list-index-container-content">
			<?php
			if( !empty( $auctions_by_user ) ) {
			?>
				<table class="shop_table shop_table_responsive my_account_orders yith_wcact_my_auctions_auction_list_index">
					<thead>
						<tr>
							<th class="product-remove"> </th>
							<th class="toptable my-auction-list-index-product"><span class="nobr"><?php echo esc_html__( 'Product', 'yith-auctions-for-woocommerce' ); ?></span></th>
							<th class="toptable my-auction-list-index-your-bid"><span class="nobr"><?php echo esc_html__( 'Your bid', 'yith-auctions-for-woocommerce' ); ?></span></th>
							<th class="toptable my-auction-list-index-current-bid"><span class="nobr"><?php echo esc_html__( 'Current bid', 'yith-auctions-for-woocommerce' ); ?></span></th>
							<th class="toptable my-auction-list-index-status"><span class="nobr"><?php echo esc_html__( 'Status', 'yith-auctions-for-woocommerce' ); ?></span></th>

						</tr>
					</thead>
					<tbody>
					<?php
					$auctions_by_user_showed = 0;
					foreach ( $auctions_by_user as $valor ) {

						if ( $auctions_by_user_showed >= $limit  ) {
							break;
						}
						$product      = wc_get_product( $valor->auction_id );
						if (! $product|| ( $product && apply_filters( 'yith_wcact_no_display_closed_auctions_on_my_auction_index', ( 'auction' == $product->get_type() && $product->is_closed() ), $product ) ) || ! $product instanceof WC_Product_Auction )
							continue;
						$auctions_by_user_showed++;
						$product_name = get_the_title( $valor->auction_id );
						$product_url  = get_the_permalink( $valor->auction_id );
						$a            = $product->get_image(  );
						$auction_product_type = $product->get_auction_type();
						$max_bid = $auction_product_type && 'reverse' === $auction_product_type ? $instance->get_min_bid( $valor->auction_id ) : $instance->get_max_bid( $valor->auction_id );
						$max_bid_value = $max_bid ? $max_bid->bid : 0;

						$bids = YITH_Auctions()->bids;
						$last_bid_user = $bids->get_last_bid_user( $user_id, $valor->auction_id );
						
						if( $max_bid->user_id == $user_id ) {
							$color = 'yith-wcact-max-bidder';
						} else {
							$color = 'yith-wcact-outbid-bidder';
						}
						?>
							<tr class="yith-wcact-auction-endpoint" data-product="<?php echo $product->get_id() ?>" >
								<td class="product-remove">
								</td>
								<td class="my-auction-list-index-product" data-title="Product">
									<span class="yith-wcact-my-account-image" style="vertical-align: middle;"><?php echo $a ?></span><a href="<?php echo $product_url; ?>"><?php echo $product_name ?></a></td>
								<td class="my-auction-list-index-your-bid yith-wcact-my-bid-endpoint yith-wcact-my-auctions order-date <?php echo $color ?>" data-title="Your bid"><?php echo apply_filters( 'yith_wcact_auction_product_price', wc_price( $last_bid_user ), $last_bid_user, $currency ); ?></td>
								<td class="my-auction-list-index-status yith-wcact-current-bid-endpoint yith-wcact-my-auctions order-total" data-title="Current bid"><?php echo 'yes' != $product->get_auction_sealed() ? apply_filters( 'yith_wcact_auction_product_price',wc_price( $product->get_price() ), $product->get_price(), $currency) : esc_html__( 'Sealed','yith-auctions-for-woocommerce'); ?></td>
								<?php
								if ( $product->is_type('auction') && $product->is_closed() ) {
									 $max_bid = $instance->get_max_bid($valor->auction_id);

									if ( $max_bid && $max_bid->user_id == $user_id && !$product->get_auction_paid_order() && ( !$product->has_reserve_price() || ($product->has_reserve_price() && $max_bid->bid >= $product->get_reserve_price())  ) ) {

										$url  = add_query_arg( array( 'yith-wcact-pay-won-auction' => $product->get_id() ), apply_filters('yith_wcact_get_checkout_url',wc_get_checkout_url(),$product->get_id() ));
										?>
										<td class="yith-wcact-auctions-status yith-wcact-my-auctions order-status" data-title="Status">
											<span><?php echo apply_filters('yith_wcact_my_account_congratulation_message',esc_html__('You won this auction','yith-auctions-for-woocommerce'));?></span>

											<?php if('yes' == get_option('yith_wcact_settings_tab_auction_show_add_to_cart_in_auction_product')){
												$url  = add_query_arg( array( 'yith-wcact-pay-won-auction' => $product->get_id() ));
											?>
												<a  href="<?php echo $url ?>" class="auction_add_to_cart_button button alt"
													id="yith-wcact-auction-won-auction">
													<?php echo sprintf(esc_html__('Add to cart', 'yith-auctions-for-woocommerce')); ?>
												</a>
											<?php

											}else{

												?>
													<a  href="<?php echo $url ?>" class="auction_add_to_cart_button button alt"
														id="yith-wcact-auction-won-auction">
														<?php echo sprintf(esc_html__('Pay now', 'yith-auctions-for-woocommerce')); ?>
													</a>
												<?php
											}?>

										</td>
										<?php
									}else {
										?>
										<td class="yith-wcact-auctions-status yith-wcact-my-auctions order-status" data-title="Status"><?php echo esc_html__('Closed', 'yith-auctions-for-woocommerce'); ?>
											<?php do_action('yith_wcact_auction_status_my_account_closed',$product,$valor); ?>
										</td>

									<?php
									}
								} else {
									?>
									<td class="yith-wcact-auctions-status yith-wcact-my-auctions order-status" data-title="Status"><?php echo esc_html__( 'Started', 'yith-auctions-for-woocommerce' ); ?>
										<?php do_action('yith_wcact_auction_status_my_account_started',$product,$valor); ?>
									</td>

									<?php
								}
								?>
							</tr>
						<?php
					}
					?>
					</tbody>

				</table>
			<?php
				} else {
			?>
				<p><?php esc_html_e('Make your first bid to see your auctions here!','yith-auctions-for-woocommerce'); ?></p>
			<?php } ?>
		</div>

		<?php if( count( $auctions_by_user ) > $limit ) {  ?>
			<div class="yith-wcact-my-auctions-list-index-container-footer">
				<a  href="<?php echo $auctions_list_url; ?>" class="ywcact-view-all-auction-list ywcact-my-account-link">
					<?php echo esc_html__('View All >', 'yith-auctions-for-woocommerce'); ?>
				</a>
			</div>
		<?php }  ?>
	</div>

<?php
	// Watchlist index section
    $whatchlist_by_user  = $instance->get_whatchlist_product_by_user( $user_id );
?>

	<div class="yith-wcact-my-watchlist-list-index-container">
		<div class="yith-wcact-my-watchlist-list-index-container-header">
			<h3><?php esc_html_e( 'My watchlist', 'yith-auctions-for-woocommerce' ); ?></h3>
		</div>
		<div class="yith-wcact-my-watchlist-list-index-container-content">
			<?php
			if( !empty( $whatchlist_by_user ) ) {
			?>
			<table class="shop_table shop_table_responsive my_account_orders yith_wcact_my_auctions_watchlist_list_index">
				<thead>
				<tr>
					<th class="product-remove"> </th>
					<th class="toptable my-auction-watchlist-list-index-product"><span class="nobr"><?php echo esc_html__( 'Product', 'yith-auctions-for-woocommerce' ); ?></span></th>
					<th class="toptable my-auction-watchlist-list-index-your-bid"><span class="nobr"><?php echo esc_html__( 'Your bid', 'yith-auctions-for-woocommerce' ); ?></span></th>
					<th class="toptable my-auction-watchlist-list-index-current-bid"><span class="nobr"><?php echo esc_html__( 'Current bid', 'yith-auctions-for-woocommerce' ); ?></span></th>
					<th class="toptable my-auction-watchlist-list-index-end-on"><span class="nobr"><?php echo esc_html__( 'End on:', 'yith-auctions-for-woocommerce' ); ?></span></th>

				</tr>
				</thead>
				<tbody>
				<?php
				$watchlist_by_user_showed = 0;

				foreach ( $whatchlist_by_user as $valor ) {

					if ( $watchlist_by_user_showed >= $limit  ) {
						break;
					}

					$product      = wc_get_product( $valor->auction_id );
					if (!$product )
						continue;
					$watchlist_by_user_showed++;
					$product_name = get_the_title( $valor->auction_id );
					$product_url  = get_the_permalink( $valor->auction_id );
					$a            = $product->get_image( );
					$auction_product_type = $product->get_auction_type();

					$max_bid = $auction_product_type && 'reverse' === $auction_product_type ? $instance->get_min_bid( $valor->auction_id ) : $instance->get_max_bid( $valor->auction_id );

					$max_bid_value = $max_bid ? $max_bid->bid : 0;

					$bids = YITH_Auctions()->bids;
					$last_bid_user = $bids->get_last_bid_user( $user_id, $valor->auction_id );
					$auction_date = $product->is_start() ? $product->get_end_date() : $product->get_start_date();

					if( $max_bid && $max_bid->user_id == $user_id ) {
						$color = 'yith-wcact-max-bidder';
					}else {
						$color = 'yith-wcact-outbid-bidder';
					}
					?>
					<tr class="yith-wcact-auction-content-my-watchlist-list" data-product="<?php echo $product->get_id() ?>" >
						<td class="product-remove">
							<div>
								<a href="<?php echo esc_url( add_query_arg( array( 'remove_from_watchlist' => $product->get_id(), 'user_id' => $user_id ) ) ); ?>" class="remove remove_from_watchlist" title="<?php echo esc_html( apply_filters( 'yith_wcwl_remove_product_wishlist_message_title', __( 'Remove this product', 'yith-auctions-for-woocommerce' ) ) ); ?>">&times;</a>
							</div>
						</td>
						<td class="my-auction-watchlist-list-index-product" data-title="Product">
							<span class="yith-wcact-my-account-image" style="vertical-align: middle;"><?php echo $a ?></span><a href="<?php echo $product_url; ?>"><?php echo $product_name ?></a></td>
						<td class="my-auction-watchlist-list-index-your-bid <?php echo $color ?>" data-title="Your bid"><?php echo apply_filters('yith_wcact_auction_product_price',wc_price( $last_bid_user ), $last_bid_user, $currency ); ?></td>
						<td class="my-auction-watchlist-list-index-current-bid" data-title="Current bid"><?php echo 'yes' != $product->get_auction_sealed() ? wc_price($product->get_price()) : esc_html__('Sealed','yith-auctions-for-woocommerce'); ?></td>
						<td class="my-auction-watchlist-list-index-end-on">

							<div class="yith-wcact-timeleft-widget-watchlist">
								<?php
								if( ! $product->is_closed() ) {
									$args = array(
										'product'           => $product,
										'auction_finish'    =>  $product->get_end_date(),
										'date'              => strtotime('now'),
										'last_minute'       => isset( $time_change_color ) ? $auction_end - $time_change_color  : 0,
										'total'             => $auction_date - strtotime('now'),
										'yith_wcact_class'  => isset( $yith_wcact_class ) ? $yith_wcact_class : 'yith-wcact-timeleft-default',
										'yith_wcact_block' => isset( $countdown_blocks ) ? $countdown_blocks : '',

									);
									wc_get_template( 'auction-timeleft.php', $args, '', YITH_WCACT_TEMPLATE_PATH . 'frontend/' );
								} else {

									echo esc_html__('Finished','yith-auctions-for-woocommerce');
								}
								?>
							</div>
						</td>
					</tr>
					<?php
				}
				?>
				</tbody>

			</table>
				<?php
			} else {
				?>
				<p><?php esc_html_e('Watch an auction to see it here!','yith-auctions-for-woocommerce'); ?></p>
			<?php } ?>
		</div>

		<?php if( count( $whatchlist_by_user ) > $limit ) {  ?>
		<div class="yith-wcact-my-watchlist-list-index-container-footer">
			<a  href="<?php echo $watchlist_list_url; ?>" class="ywcact-view-all-my-watchlist ywcact-my-account-link">
				<?php echo esc_html__('View All >', 'yith-auctions-for-woocommerce'); ?>
			</a>
		</div>
		<?php }  ?>
	</div>

</div>
