<?php
/**
 * Auction product add to cart
 *
 * @author 		Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

global $product;

$product_wpml = $product; //Fix redirect url problem with WPML active
$product = apply_filters('yith_wcact_get_auction_product',$product);



?>

<?php

if ( 'yes' == get_option('yith_wcact_show_product_stock', 'yes' ) ) {
// Availability
	$availability = $product->get_availability();
	$availability_html = empty( $availability['availability'] ) ? '' : '<p class="stock ' . esc_attr( $availability['class'] ) . '">' . esc_html( $availability['availability'] ) . '</p>';

	echo apply_filters( 'woocommerce_get_stock_html', $availability_html, $product );
}
?>

<?php do_action('yith_wcact_before_add_to_cart_form',$product) ?>

<?php if ( $product->is_in_stock() ) { ?>

    <?php do_action( 'woocommerce_before_add_to_cart_form' ); ?>
    <?php
        if( apply_filters('yith_wcact_before_add_to_cart',true,$product ) ) {

            //Auction started and it's not closed
            if ( $product->is_start() && !$product->is_closed() ) {

                $auction_finish = ( $datetime = $product->get_end_date() ) ? $datetime : NULL;
                $date = strtotime('now');

                $user = wp_get_current_user();

                if( $user instanceof WP_User  && $user->ID > 0 ) {

                    $is_banned = get_user_meta($user->ID, '_yith_wcact_user_ban', true);
                    $ban_message = get_user_meta($user->ID, '_yith_wcact_ban_message', true);

					$stripe_checked = false;

					if( defined( 'YITH_WCSTRIPE_PREMIUM' ) && 'yes' == get_option('yith_wcact_verify_payment_method','no') ) {
						$tokens = WC_Payment_Tokens::get_customer_tokens( $user->ID );
						if( empty( $tokens ) ) {
							$stripe_checked = true;
						}
					}


                }

                do_action('yith_wcact_before_form_auction_product',$product);
                ?>
                <form class="cart" method="post" enctype='multipart/form-data'>

                   <div class="yith-wcact-main-auction-product">

                        <?php
                        $bid_increment = 1;
                        $total = $auction_finish - $date;

                        do_action('yith_wcact_in_to_form_add_to_cart',$product);

                        ?>

                        <div id="time" class="timetito" data-finish-time="<?php echo $auction_finish ?>" data-remaining-time=" <?php echo $total ?>" data-bid-increment="<?php echo $bid_increment ?>" data-currency="<?php echo get_woocommerce_currency(); ?>" data-product="<?php echo $product_wpml->get_id()?>"data-current="<?php echo $product->get_price()?>"data-finish="<?php echo $auction_finish?>">

                            <div class="yith-wcact-time-left-main">

                                <div id="yith-wcact-auction-timeleft">

		                            <?php do_action('yith_wcact_auction_before_set_bid',$product) ?>

                                </div>

                            </div>

                            <?php do_action('woocommerce_before_add_to_cart_button'); ?>

                            <?php if ( !isset( $is_banned ) || !$is_banned )  { ?>

                                <?php do_action('yith_wcact_before_form_bid', $product, $user); ?>
								<?php if( ! isset( $stripe_checked ) || ( isset( $stripe_checked ) && ! $stripe_checked ) ) {

									$buttons = get_option('yith_wcact_settings_tab_auction_show_button','theme');
									$input_class_quantity = ( 'theme' == $buttons ) ? array( 'input-text', 'qty', 'text','ywcact-wcact-bid-type-'.$buttons, 'ywcact-bid-input' ) : array( 'input-text', 'qty', 'text', 'yith-wcact-bid-quantity','ywcact-wcact-bid-type-'.$buttons, 'ywcact-bid-input' ) ;


									?>
                               	 <div name="form_bid" id="yith-wcact-form-bid" class="ywcact-bid-form ywcact-wcact-bid-form-<?php echo $buttons;?>">

                                    <div class="ywcact-your-bid-header">
											<?php

											if ( !$product->calculate_bid_up_increment()  ) {
												?>
													<p><?php esc_html_e('Your bid:', 'yith-auctions-for-woocommerce'); ?></p>
												<?php
											} else {
												$bidup = esc_html__('Your automatic bid:', 'yith-auctions-for-woocommerce');

												$show_modal = 'yes' === get_option( 'yith_wcact_settings_show_automatic_bidding_modal_info', 'no' ) ? true : false;

												?>
												<p>
													<span id="yith-wcact-showbidup"><?php echo wp_kses_post( $bidup ); ?></span>
													<?php
														if ( $show_modal ) {
														?>
															<span title="" class="yith-auction-help-tip yith-wcact-popup-button" data-ywcact-content-id=".yith-wcact-show-bidup-modal"> </span>
															<div class="yith-wcact-show-bidup-modal" style="display: none">
																<div class="yith-wcact-modal-title">
																	<h4><?php esc_html_e( 'How automatic bidding works?', 'yith-auctions-for-woocommerce' ); ?></h4>
																</div>
																<div class="yith-wcact-modal-content">
																	<p>
																		<?php esc_html_e( "You can enter the maximum you're willing to pay for this item. Our system will bid for you, with the smallest amount possible every time, making sure you are always one step ahead of the other bidders", 'yith-auctions-for-woocommerce' ); ?>
																	</p>
																	<p>
																		<?php esc_html_e( 'Once you have reached your maximum limit, we will notify you and no longer bid on your name unless you decide to set up a new automatic bid.', 'yith-auctions-for-woocommerce' ); ?>
																	</p>
																</div>
															</div>
															<span class="yith-wcact-show-bidup-modal" style=" display: none;"><?php echo esc_html__( 'Total used from pool of money for automatic bid up.', 'yith-auctions-for-woocommerce' ); ?> </span>
														<?php } else { ?>

															<!--	<span title="<?php echo esc_html__( 'Total used from pool of money for automatic bid up.', 'yith-auctions-for-woocommerce' ); ?>" <?php echo ( 'yes' === $showbidup ) ? 'class="yith-auction-help-tip yith-auction-help-tip-tooltip"' : ''; ?>></span> </br> -->
															<?php
															}
													} ?>
												</p>

											</div>

                                    <?php

                                    if ('custom' == $buttons ) {

                                    ?>
                                        <div class="yith-wcact-bid-section" >

                                        <input type="button" class="bid button_bid_subtr" value="-">

                                    <?php
                                    }
                                    ?>
											<span class="ywcact-currency-symbol ywcact-currency-value"><?php echo get_woocommerce_currency_symbol() ?></span>

	                                <?php
                                    $current_bid = $product->get_current_bid();
	                                $min_incr_amount = (int)( $product->get_minimum_increment_amount() ) ? $product->get_minimum_increment_amount() : 1;
	                                $actual_amount = '';
	                                $auction_sealed = 'no' == $product->get_auction_sealed();
	                                $min_value = ( $auction_sealed ) ? $current_bid + $min_incr_amount : 0;
	                                $max_value = '';
	                                $instance     = YITH_Auctions()->bids;
	                                $bids = $instance->get_bids_auction( $product->get_id() );

	                                if  ( 'yes' == get_option('yith_wcact_show_next_available_amount','no' ) && $auction_sealed ) {

										if ( 'reverse' == $product->get_auction_type() ) {

											$actual_amount = $current_bid - $min_incr_amount;
											$min_value = 0;
											$max_value = $current_bid - $min_incr_amount;;

										} else {
											if( $product->get_price() == $product->get_start_price() && empty( $bids ) ) {
												$min_value = $current_bid;
												$actual_amount = $current_bid;
											}else {
												$min_value = $min_incr_amount + $current_bid;
												$actual_amount = $min_incr_amount + $current_bid;
											}
											$max_value = '';
										}
									}
	                                woocommerce_quantity_input(
		                                array(
			                                'input_id'    => '_actual_bid',
			                                'classes'     => apply_filters( 'yith_wcact_quantity_input_classes', $input_class_quantity, $product ),
			                                'input_name'  => 'ywcact_bid_quantity',
			                                'min_value'   => apply_filters( 'woocommerce_quantity_input_min', $min_value , $product ),
			                                'max_value'   => apply_filters( 'woocommerce_quantity_input_max', $max_value, $product ),
			                                'step'        => apply_filters( 'yith_wcact_quantity_input_step', $min_incr_amount, $product ),
			                                'input_value' => apply_filters('yith_wcact_actual_bid_value',$actual_amount,$product),
		                                )
	                                );

	                                ?>

									<?php

                                    if ('custom' == $buttons ) {
                                        ?>
                                        <input type="button" class="bid button_bid_add" value="+">

                                        </div>
                                        <?php
                                    }

                                        do_action('yith_wcact_after_form_bid',$product);
                                    ?>

                                    <?php do_action('yith_wcact_before_add_button_bid',$product) ?>

                                    <?php $bid_class_button = apply_filters('yith_wcact_auction_button_bid_class','auction_bid button alt', $product, $user ); ?>
                                    <button type="button" class="<?php echo $bid_class_button; ?>"><?php echo apply_filters('yith_wcact_bid_button_label', esc_html__('Bid', 'yith-auctions-for-woocommerce')) ; ?></button>



				   </div>
								<?php } else {

									$payment_method_url = yith_wcact_get_payment_method_url();

									?>
									<div class="ywcact-add-yith-wcstripe-message">

										<p><?php echo sprintf( __( 'You need to add a valid credit card in the <a href="%s" target="_blank">%2s</a> section in order to bid.', 'yith-auctions-for-woocommerce' ), $payment_method_url, 'Payment method' ) ?></p>
									</div>
									<?php

								} ?>
	                            <?php do_action('yith_wcact_after_add_button_bid',$product_wpml) ?>


                            <?php } else {

                                    if( $is_banned ) {
	                                    ?>
                                        <div class="yith-wcact-ban-message-section">
                                            <p class="yith-wcact-ban-message"> <?php echo $ban_message ?> </p>
                                        </div>

	                                    <?php
                                    }
                            } ?>
                        </div>

                        <?php do_action('woocommerce_after_add_to_cart_button'); ?>

                        </div>

                    </form>

                    <?php do_action( 'yith_wcact_after_add_to_cart_form',$product); ?>

        <?php
            } elseif ( !$product->is_closed() || !$product->is_start() ) { //Auction not started

	            $for_auction = ($datetime = $product->get_start_date()) ? $datetime : NULL;
                $date = strtotime('now');

	            $args = array(
		            'product'           => $product,
		            'product_id'        => $product->get_id(),
		            'auction_finish'    =>  $for_auction,
		            'date'              => $date,
		            'total'             => $for_auction - $date,
					'last_minute'       =>  0,
					'yith_wcact_class'  => isset( $yith_wcact_class ) ? $yith_wcact_class : 'yith-wcact-timeleft-default yith-wcact-timeleft-product-page',
					'yith_wcact_block' => isset( $countdown_blocks ) ? $countdown_blocks : '',
				);

                    ?>
                    <h3><?php echo apply_filters('yith_wcact_auction_not_available_message', esc_html__('This auction has not been started yet', 'yith-auctions-for-woocommerce'),$product) ?></h3>
                    <div id="time">

						<div class="yith-wcact-time-left-main">

							<div id="yith-wcact-auction-timeleft">

								<?php do_action('yith_wcact_auction_before_set_bid',$product, 'not_started' ) ?>


							</div>

						</div>
                    </div>

				<?php do_action('yith_wcact_after_no_start_auction',$product_wpml) ?>
                <?php
                //The auction end
            } else {
                
                do_action('yith_wcact_auction_end',$product);

            }
        }
    ?>
    <?php do_action( 'woocommerce_after_add_to_cart_form' ); ?>

<?php } else {

	do_action('yith_wcact_auction_end',$product);

} ?>

