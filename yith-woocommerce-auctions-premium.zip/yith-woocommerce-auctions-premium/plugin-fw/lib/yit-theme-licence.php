<?php
/**
 * Deprecated file. Use the correct one in includes folder instead
 *
 * @package YITH\PluginFramework\Classes
 */

/**
 * Require the correct file
 */
require_once __DIR__ . '/../includes/class-yit-theme-licence.php';
