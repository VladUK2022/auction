jQuery( function($) {


	$('#reshedule_button').on('click',function(){
		$('#yith_auction_settings').block({message:null, overlayCSS:{background:"#fff",opacity:.6}});
		var post_data = {
			'id': object.id,
			//security: object.search_post_nonce,
			action: 'yith_wcact_reshedule_product'
		};

		$.ajax({
			type    : "POST",
			data    : post_data,
			url     : object.ajaxurl,
			success : function ( response ) {
				$('#yith_auction_settings').unblock();
				$('#reshedule_button').hide();
				$('#yith-reshedule-notice-admin').show();
				$('#_stock_status').val('instock');
				//window.location.reload();
				// On Success
			},
			complete: function () {
			}
		});
	});

	$('.yith-wcact-delete-bid').on('click',function(e){
		e.preventDefault();
		$('#yith-wcgpf-auction-bid-list').block({message:null, overlayCSS:{background:"#fff",opacity:.6}});

		if(window.confirm(object.confirm_delete_bid)){
			var post_data = {
				'user_id': $(this).data('user-id'),
				'product_id': $(this).data('product-id'),
				'date' : $(this).data('date-time'),
				'bid': $(this).data('bid'),
				action: 'yith_wcact_delete_customer_bid'
			};

			$.ajax({
				type    : "POST",
				data    : post_data,
				url     : object.ajaxurl,
				success : function ( response ) {
					current_target          = $( e.target );
					parent                  = current_target.closest( '.yith-wcact-row' );
					parent.remove();
					$('#yith-wcgpf-auction-bid-list').unblock();
				},
				complete: function () {
				}
			});

		} else {
			$('#yith-wcgpf-auction-bid-list').unblock();
		}

	})


	$(document.body).on('yith_wcact_send_winner_email_button',function () {

        $('#yith-wcact-send-winner-email').on('click',function(){
            $('.yith-wcact-admin-auction-status').block({message:null, overlayCSS:{background:"#fff",opacity:.6}});
            var post_data = {
                'id': object.id,
                //security: object.search_post_nonce,
                action: 'yith_wcact_resend_winner_email'
            };

            $.ajax({
                type    : "POST",
                data    : post_data,
                url     : object.ajaxurl,
                success : function ( response ) {
                    $('.yith-wcact-admin-auction-status').empty();
                    $('.yith-wcact-admin-auction-status').html( response['resend_winner_email'] );
                    $(document.body).trigger('yith_wcact_send_winner_email_button');
                    $('.yith-wcact-admin-auction-status').unblock();
                },
                complete: function () {
                }
            });
        });
    });


	$(document.body).trigger('yith_wcact_send_winner_email_button');

	$( document ).find( '._tax_status_field' ).closest( 'div' ).addClass( 'show_if_auction' );

	$( 'select#product-type' ).trigger('change');

	/*General settings*/
	$( "input[name='yith_wcact_settings_automatic_bid_type']" ).on('click',function() {

		switch ( this.value ) {

			case 'simple' :
					$('.ywcact-automatic-bid-increment-simple').removeClass('ywcact-hide');
					$('.ywcact-automatic-bid-increment-simple').addClass('ywcact-show');
					$('.ywcact-automatic-bid-increment-advanced').removeClass('ywcact-show');
					$('.ywcact-automatic-bid-increment-advanced').addClass('ywcact-hide');
				break;

			case 'advanced' :
				$('.ywcact-automatic-bid-increment-simple').removeClass('ywcact-show');
				$('.ywcact-automatic-bid-increment-simple').addClass('ywcact-hide');
				$('.ywcact-automatic-bid-increment-advanced').removeClass('ywcact-hide');
				$('.ywcact-automatic-bid-increment-advanced').addClass('ywcact-show');
				break;


		}
	});

	$('.ywcact-add-rule').on('click',function (e) {

		let row = $( '.ywcact-automatic-bid-increment-advanced-rule:last' ).clone().css( {'display': 'none'} );
		let numItems = $('.ywcact-bid-increment-row').length;
		row.find( 'input' ).val( '' );
		row.insertBefore( $( ".ywcact-automatic-bid-increment-advanced-end" ) );
		row.removeClass('ywcact-hide');
		row.addClass('ywcact-bid-increment-row');
		$(row).find('.ywcact-remove-rule').bind("click", function() {
			row.remove();
			reassign_id();
		});

		let inputs = $( row ).find( "input" );
		let actualinput = parseInt(numItems) - 1;
		
		$(inputs).each(function (i) {
			let data_type = $(this).data('input-type');
			$(this).attr('name','ywcact_automatic_bid_advanced['+actualinput+']['+data_type+']');
		});

		let end = $( ".ywcact-automatic-bid-increment-advanced-end" );
		let inputs_end = $( end ).find( "input" );
		$(inputs_end).each(function (i) {
			let data_type = $(this).data('input-type');
			$(this).attr('name','ywcact_automatic_bid_advanced['+numItems+']['+data_type+']');
		});


		row.fadeTo(
			400,
			1,
			function () {
				row.css( {'display': 'block'} );
			}
		);
	});

	$('.ywcact-remove-rule').on('click',function () {

		let row = $(this).closest('.ywcact-automatic-bid-increment-advanced-rule');
		row.remove();
		reassign_id();

	});

	function reassign_id() {
		$('.ywcact-bid-increment-row').each(function (j) {

			let inputs = $( this ).find( "input" );

			$(inputs).each(function (i) {
				let data_type = $(this).data('input-type');
				$(this).attr('name','ywcact_automatic_bid_advanced['+j+']['+data_type+']');
			});
		});
	}

	/* == Change auction by default == */

	if( object.auction_by_default  ) {
		$("#product-type").val('auction').trigger('change');
		$(".yith_Auction_options a").trigger('click');
	}

	var productType = $("#product-type");
	var canSubmit = false;
	var error_field = [];
		isAuction   = function(){
			return 'auction' === productType.val();
		};
		dataValidation = function() {
			 var nodisplayMessage = true;
			$('.ywcact-data-validation').each( function (  ) {

				if(!$(this).val()) {
					$( this ).addClass( "ywcact-data-validation-error" );
					var field_name = $(this).data('title-field');
					error_field.push( field_name );
					nodisplayMessage = false;
				}

			} );

			return nodisplayMessage;
		};
		checkForFields = function() {
			var checkfields = false;
			var button_clicked = $("input[type=submit][ywcact-clicked=true]").attr("id");

			if ('publish' === button_clicked ) {

				var original_post_status = $('#original_post_status').val();
				var post_status = $('#post_status').val();

				if( 'publish' === original_post_status && 'publish' === post_status ) {
					checkfields = true;
				} else if( 'draft' === original_post_status || 'auto-draft' === original_post_status  ) {
					checkfields = true;
				}

			}


			return checkfields;

		};
		notice_reset = function() {
			$('.ywcact-notice').remove();
			$('.ywcact-data-validation-error').removeClass('ywcact-data-validation-error');
			error_field = [];
		};
	$('#post').on('submit', function(e){

		if ( isAuction() && !canSubmit && checkForFields() ){
			notice_reset();
			if ( dataValidation() ){
				canSubmit = true;
				$('#publish').trigger('click');
			} else {
				e.preventDefault();

				var original_message =  object.error_validation;
				var error_count = error_field.length;
				var error_message = '';
				var i = 0;
				error_field.forEach(function(valor, indice, array) {
					console.log(valor);
					var sep = ( ++i === error_count ) ? '' : ', ';
					error_message = error_message+valor+sep;
				});
				console.log(error_message);

				var message = original_message.replace("%s", error_message );

				var message_block = "<div class='ywcact-notice ywcact-notice-error'><p><span class=\"dashicons dashicons-warning\"></span><span class='ywcact-notice-error-message'>"+message+"</span></p></div>";
				$(message_block).insertBefore($('div.wrap #poststuff'));
			}
		}
	});

	$("#post input[type=submit]").click(function() {
		$("input[type=submit]", $(this).parents("form")).removeAttr("ywcact-clicked");
		$(this).attr("ywcact-clicked", "true");
	});

});
