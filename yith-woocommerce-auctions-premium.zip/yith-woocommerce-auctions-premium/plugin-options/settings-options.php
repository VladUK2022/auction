<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

$regenerate_price_url  = add_query_arg( array( 'yith-wcact-action' => 'regenerate_auction_prices' ) );
$yith_wceasy_landing   = 'https://yithemes.com/themes/plugins/yith-easy-login-register-popup-for-woocommerce/';
$yith_wcstripe_landing = 'https://yithemes.com/themes/plugins/yith-woocommerce-stripe/';
$resend_winner_email_url = add_query_arg(array('yith-wcact-action-resend-email' => 'send_auction_winner_email'));


return array(

	'settings' => array(

		'settings_options_start'                          => array(
			'type' => 'sectionstart',
			'id'   => 'yith_wcact_settings_options_start',
		),

		'settings_options_title'                          => array(
			'title' => esc_html_x( 'General settings', 'Panel: page title', 'yith-auctions-for-woocommerce' ),
			'type'  => 'title',
			'desc'  => '',
			'id'    => 'yith_wcact_settings_options_title',
		),

		'settings_show_auctions_shop_page'                => array(
			'title'     => esc_html_x( 'Show auctions on the shop page', 'Admin option: Show auctions on the shop page', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => implode(
				'<br />',
				array(
					esc_html__( 'Enable to show auction products in the shop page.', 'yith-auctions-for-woocommerce' ),
					esc_html__( 'If disabled, all auctions will be shown only in the page with the auction shortcode.', 'yith-auctions-for-woocommerce' ),
				)
			),
			'id'        => 'yith_wcact_show_auctions_shop_page',
			'default'   => 'yes',
		),

		'settings_hide_auctions_out_of_stock'             => array(
			'title'     => esc_html_x( 'Hide out-of-stock auctions', 'Admin option: Hide out-of-stock auctions', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html_x( 'Enable to hide out-of-stock auctions in the shop pages', 'Admin option description: Enable to hide out-of-stock auctions in shop pages', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_hide_auctions_out_of_stock',
			'default'   => 'no',
			'deps'      => array(
				'id'    => 'yith_wcact_show_auctions_shop_page',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'settings_hide_auctions_closed'                   => array(
			'title'     => esc_html_x( 'Hide ended auctions', 'Admin option: Hide ended auctions', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html_x( 'Enable to hide ended auctions in shop page', 'Admin option description: Enable to hide ended auctions in shop page', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_hide_auctions_closed',
			'default'   => 'no',
			'deps'      => array(
				'id'    => 'yith_wcact_show_auctions_shop_page',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'settings_hide_auctions_not_started'              => array(
			'title'     => esc_html_x( 'Hide future auctions', 'Admin option: Hide future auctions', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html_x( 'Enable to hide auctions, that have not yet started, in the shop page', 'Admin option description: Enable to hide auctions not started yet in shop page', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_hide_auctions_not_started',
			'default'   => 'no',
			'deps'      => array(
				'id'    => 'yith_wcact_show_auctions_shop_page',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'settings_show_countdown_in_loop'                 => array(
			'title'     => esc_html__( 'Show countdown in loop', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => implode(
				'<br />',
				array(
					esc_html__( 'Enable to show auctions countdown or end time also in the shop pages.', 'yith-auctions-for-woocommerce' ),
					esc_html__( 'If disabled, countdown will only be shown in the auction page.', 'yith-auctions-for-woocommerce' ),
				)
			),
			'id'        => 'yith_wcact_show_countdown_in_loop',
			'default'   => 'no',
		),
		'settings_hide_buy_now_bid_exceed_buy_now_price'  => array(
			'title'     => esc_html__( 'Hide \'Buy Now\' when a bid exceeds the buy now price', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => implode(
				'<br />',
				array(
					esc_html__( 'Enable to hide \'Buy Now\' button when a user bids an amount that exceeds the', 'yith-auctions-for-woocommerce' ),
					esc_html__( '\'Buy Now\' price.', 'yith-auctions-for-woocommerce' ),
				)
			),
			'id'        => 'yith_wcact_settings_hide_buy_now_price_exceed',
			'default'   => 'no',
		),
		'settings_hide_buy_now_after_first_bid'           => array(
			'title'     => esc_html__( 'Hide \'Buy Now\' after the first bid', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to hide \'Buy Now\' button when a user places the first bid.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_hide_buy_now_after_first_bid',
			'default'   => 'no',
		),
		'settings_set_bid_type'                           => array(
			'title'     => esc_html__( 'Set bid type', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'radio',
			'options'   => array(
				'manual'    => esc_html__( 'Manual', 'yith-auctions-for-woocommerce' ),
				'automatic' => esc_html__( 'Automatic', 'yith-auctions-for-woocommerce' ),
			),
			'default'   => 'manual',
			'id'        => 'yith_wcact_settings_bid_type',
			'desc'      => implode(
				'<br />',
				array(
					esc_html__( 'With the automatic bidding the user enters the maximum he is willing to pay for the item.', 'yith-auctions-for-woocommerce' ),
					esc_html_x( 'The system will automatically bid for him with the smallest amount possible every time, until the user\'s maximum limit has been reached. ', 'The system will automatically bid for him with the smallest amount posible every time, once his maximun limit is reached', 'yith-auctions-for-woocommerce' ),
				)
			),
		),
		'settings_automatic_bid_type'                     => array(
			'title'     => esc_html__( 'Automatic bid type', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'radio',
			'options'   => array(
				'simple'    => esc_html__( 'Simple', 'yith-auctions-for-woocommerce' ),
				'advanced' => esc_html__( 'Advanced', 'yith-auctions-for-woocommerce' ),
			),
			'default'   => 'simple',
			'id'        => 'yith_wcact_settings_automatic_bid_type',
			'desc'      => implode(
				'<br />',
				array(
					esc_html_x( 'With the simple type you can set only one bid increment amount, independently from the current bid value.', 'The system will automatically bid for him with the smallest amount posible every time, once his maximun limit is reached.', 'yith-auctions-for-woocommerce' ),
					esc_html__( 'With the advanced type you can set different auctomatic bid increments based on current bid value.', 'yith-auctions-for-woocommerce' ),
				)
			),
			'deps'      => array(
				'id'    => 'yith_wcact_settings_bid_type',
				'value' => 'automatic',
				'type'  => 'hide',
			),
		),
		'settings_automatic_bid_increment'                => array(
			'title'           => sprintf( esc_html_x( 'Automatic bid increment (%s)', 'Automatic bid increment ($)', 'yith-auctions-for-woocommerce' ), get_woocommerce_currency_symbol() ),
			'id'              => 'yith_wcact_settings_automatic_bid_increment',
			'type'            => 'yith-field',
			'yith-type'       => 'custom',
			'yith-wcact-type' => 'automatic-bid-increment',
			'desc'            => esc_html__( 'Set the bidding increment for automatic bidding. You can create more rules to set different bid increments based on the auction\'s current bid and then set a last rule to cover all the offers made after the last current bid step ', 'yith-auctions-for-woocommerce' ),
			'action'          => 'yith_wcact_general_custom_fields',
			'deps'            => array(
				'id'    => 'yith_wcact_settings_bid_type',
				'value' => 'automatic',
				'type'  => 'hide',
			),
		),
		'settings_show_bid_increment_in_the_page'         => array(
			'title'     => esc_html__( 'Show the bid increments in the page', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to show the automatic bid increment info in the page.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_show_bid_increment_in_the_page',
			'default'   => 'no',
		),
		'settings_show_automatic_bidding_modal_info'      => array(
			'title'     => esc_html__( 'Show automatic bidding modal info', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to show a modal that explains how automatic bidding works.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_show_automatic_bidding_modal_info',
			'default'   => 'no',
			'deps'            => array(
				'id'    => 'yith_wcact_settings_bid_type',
				'value' => 'automatic',
				'type'  => 'hide',
			),
		),
		'settings_ask_confirmation_before_to_bid'          => array(
			'title'     => esc_html__( 'Ask for approval before a bid is confirmed', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'If enabled, bidders will see a modal window that asks them to confirm the bid before publishing it.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_ask_confirmation_before_to_bid',
			'default'   => 'no',
		),
		'settings_ask_fee_payment_before_to_bid'          => array(
			'title'     => esc_html__( 'Ask fee payment before bidding', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to ask users to pay a fee before placing a bid.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_ask_fee_before_to_bid',
			'default'   => 'no',
		),
		'settings_default_fee_amount'                     => array(
			'title'     => sprintf( esc_html_x( 'Default fee amount (%s)', 'Default fee amount ($)', 'yith-auctions-for-woocommerce' ), get_woocommerce_currency_symbol() ),
			'id'        => 'yith_wcact_settings_fee_amount',
			'type'      => 'yith-field',
			'yith-type' => 'text',
			'default'   => 10,
			'desc'      => implode(
				'<br />',
				array(
					esc_html__( 'Set the default fee that users have to pay before bidding.', 'yith-auctions-for-woocommerce' ),
					esc_html_x( 'This value can be overwritten in all auction products if you want to set a different fee for a specific auction. ', 'This value can be overwrite in all auction products if you want to set a different fee for a specific auction. ', 'yith-auctions-for-woocommerce' ),
				)
			),
			'deps'      => array(
				'id'    => 'yith_wcact_settings_ask_fee_before_to_bid',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'settings_set_overtime'                           => array(
			'title'     => esc_html__( 'Set Overtime', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to extend the auction duration if someone places a bid when the auction is about to end.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_set_overtime',
			'default'   => 'no',
		),
		'settings_set_overtime_values'                    => array(
			'id'              => 'yith_wcact_settings_set_overtime_values',
			'title'           => esc_html__( 'Overtime settings', 'yith-auctions-for-woocommerce' ),
			'type'            => 'yith-field',
			'yith-type'       => 'custom',
			'yith-wcact-type' => 'general-overtime',
			'desc'            => esc_html__( 'Set the overtime rule when the auction is about to end', 'yith-auctions-for-woocommerce' ),
			'action'          => 'yith_wcact_general_custom_fields',
			'deps'      => array(
				'id'    => 'yith_wcact_settings_set_overtime',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),

		'settings_show_higher_bidder_modal'               => array(
			'title'     => esc_html__( 'Show higher bidder modal', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to show a modal to the highest bidder to suggest him to refresh the page.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_show_higher_bidder_modal',
			'default'   => 'no',
		),
		'settings_enable_watchlist'                       => array(
			'title'     => esc_html__( 'Enable watchlist', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to allow logged in users to create a watchlist with auctions they are interested in.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_enable_watchlist',
			'default'   => 'no',
		),
		'settings_options_end'                            => array(
			'type' => 'sectionend',
			'id'   => 'yith_wcact_settings_options_end',
		),

		// CRON SETTINGS.

		'settings_cron_auction_options_start'             => array(
			'type' => 'sectionstart',
			'id'   => 'yith_wcact_settings_cron_auction_start',
		),

		'settings_cron_auction_options_title'             => array(
			'title' => esc_html_x( 'Cron settings', 'Panel: page title', 'yith-auctions-for-woocommerce' ),
			'type'  => 'title',
			'desc'  => '',
			'id'    => 'yith_wcact_settings_cron_auction_title',
		),

		'settings_cron_auction_users_follow_auction'      => array(
			'title'     => esc_html__( 'Allow users to follow auctions', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'If enabled, users can leave their email in the auction page and receive a notification when auction is about to end', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_tab_auction_allow_subscribe',
			'default'   => 'no',
		),

		'settings_cron_auction_send_emails'               => array(
			'title'     => esc_html__( 'Send emails to bidders before the auction end', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'If enabled, bidders that participate to an auction will receive an email when auctions are about to end', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_cron_auction_send_emails',
			'default'   => 'no',
		),
		'settings_cron_send_email_to_bidders'             => array(
			'id'              => 'yith_wcact_settings_cron_send_email_to_bidders',
			'title'           => esc_html__( 'Send email to bidders', 'yith-auctions-for-woocommerce' ),
			'type'            => 'yith-field',
			'yith-type'       => 'custom',
			'yith-wcact-type' => 'send-email-bidders',
			'desc'            => esc_html__( 'Choose when to send the email to bidders to let them know the auction is about to end', 'yith-auctions-for-woocommerce' ),
			'action'          => 'yith_wcact_general_custom_fields',
			'deps'            => array(
				'id'    => 'yith_wcact_settings_cron_auction_send_emails',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'settings_tab_auction_no_winner_email'            => array(
			'title'     => esc_html__( 'Send email to bidders that loose an auction', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'If enabled, bidders that participate in an auction and lose it will receive an email when the auction has ended.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_tab_auction_no_winner_email',
			'default'   => 'no',
		),
		'settings_cron_auction_options_end'               => array(
			'type' => 'sectionend',
			'id'   => 'yith_wcact_settings_cron_auction_end',
		),

		// End Cron Settings.

		// Auction Rescheduling.
		'settings_automatic_reschedule_auctions_start'    => array(
			'type' => 'sectionstart',
			'id'   => 'yith_wcact_settings_automatic_reschedule_auctions_start',
		),

		'settings_automatic_reschedule_auctions_title'    => array(
			'title' => esc_html_x( 'Auction rescheduling', 'Panel: page title', 'yith-auctions-for-woocommerce' ),
			'type'  => 'title',
			'desc'  => '',
			'id'    => 'yith_wcact_settings_automatic_reschedule_auctions_title',
		),
		'settings_auction_reschedule_without_bid'         => array(
			'title'     => esc_html__( 'Reschedule ended auctions without bids', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to automatically reschedule ended auctions without a bid', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_reschedule_auctions_without_bids',
			'default'   => 'no',
		),
		'settings_auction_reschedule_reserve_price_reached' => array(
			'title'     => esc_html__( 'Reschedule ended auctions with the reserve price not reached', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to automatically reschedule ended auctions if the reserve price was not reached by any submitted bids.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_reschedule_auctions_reserve_price_reached',
			'default'   => 'no',
		),
		'settings_auction_reschedule_for_another'         => array(
			'id'              => 'yith_wcact_reschedule_for_another',
			'title'           => esc_html__( 'Auctions will be rescheduled for another', 'yith-auctions-for-woocommerce' ),
			'type'            => 'yith-field',
			'yith-type'       => 'custom',
			'yith-wcact-type' => 'rescheduled-for-another',
			'desc'            => esc_html__( 'Set the length of time for which the auction will run again. The auction will reset itself to the original auction product settings and all previous bids will be removed.', 'yith-auctions-for-woocommerce' ),
			'action'          => 'yith_wcact_general_custom_fields',
		),
		'settings_auction_reschedule_not_paid'            => array(
			'title'     => esc_html__( 'Reschedule non-paid auctions', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to automatically reschedule auctions which are not paid by the winner', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_reschedule_auctions_not_paid',
			'default'   => 'no',
		),

		'settings_auction_reschedule_how_to_not_paid'     => array(
			'id'              => 'yith_wcact_auction_reschedule_how_to_not_paid',
			'title'           => esc_html__( 'Set how to reschedule non-paid auctions', 'yith-auctions-for-woocommerce' ),
			'type'            => 'yith-field',
			'yith-type'       => 'custom',
			'yith-wcact-type' => 'rescheduled-not-paid',
			'action'          => 'yith_wcact_general_custom_fields',
			'deps'            => array(
				'id'    => 'yith_wcact_settings_reschedule_auctions_not_paid',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),

		'settings_auction_reschedule_not_paid_change_for_another' => array(
			'id'              => 'yith_wcact_auction_reschedule_not_paid_change_for_another',
			'title'           => esc_html__( 'Non-paid auctions will be rescheduled for another ', 'yith-auctions-for-woocommerce' ),
			'type'            => 'yith-field',
			'yith-type'       => 'custom',
			'yith-wcact-type' => 'rescheduled-not-paid-for-another',
			'desc'            => esc_html__( 'Set the length of time for which the auction will run again. The auction will reset itself to the original auction product settings and all previous bids will be removed.', 'yith-auctions-for-woocommerce' ),
			'action'          => 'yith_wcact_general_custom_fields',
			'deps'            => array(
				'id'    => 'yith_wcact_settings_reschedule_auctions_not_paid',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),

		'settings_automatic_reschedule_auctions_end'      => array(
			'type' => 'sectionend',
			'id'   => 'yith_wcact_settings_automatic_reschedule_auctions_end',
		),
		// End Auction Rescheduling.

		// Ajax Refresh.
		'settings_ajax_refresh_auction_options_start'      => array(
			'type' => 'sectionstart',
			'id'   => 'yith_wcact_settings_live_auction_start',
		),

		'settings_ajax_refresh_auction_options_title'      => array(
			'title' => esc_html_x( 'Ajax Refresh', 'Panel: page title', 'yith-auctions-for-woocommerce' ),
			'type'  => 'title',
			'desc'  => '',
			'id'    => 'yith_wcact_settings_live_auction_title',
		),
		'settings_ajax_refresh_auction_product_page_onoff' => array(
			'title'     => esc_html__( 'Automatically refresh the auction page in Ajax', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to automatically refresh the auction page in Ajax. In this way the users will see the auction updates before having to reload the page.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_ajax_refresh_auction_product_page',
			'default'   => 'no',
		),
		'settings_ajax_refresh_auction_product_page'       => array(
			'title'             => esc_html__( 'Refresh auction page each (seconds)', 'yith-auctions-for-woocommerce' ),
			'type'              => 'yith-field',
			'yith-type'         => 'number',
			'class'             => 'ywcact-input-text',
			'desc'              => esc_html__( 'Set how often to automatically refresh the auction page', 'yith-auctions-for-woocommerce' ),
			'id'                => 'yith_wcact_settings_live_auction_product_page',
			'step' => 1,
			'min'  => 0,
			'default'           => 0,
			'deps'              => array(
				'id'    => 'yith_wcact_ajax_refresh_auction_product_page',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'settings_ajax_refresh_auction_my_auctions_onoff'  => array(
			'title'     => esc_html__( 'Automatically refresh info in My Account > My auctions in Ajax', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to automatically refresh the "My auctions" section in "My account" in Ajax. In this way, the users will see the auction updates before reloading the page.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_ajax_refresh_auction_my_acutions_page',
			'default'   => 'no',
		),
		'settings_ajax_refresh_auction_my_auctions'        => array(
			'title'             => esc_html_x( 'Refresh "My auctions" section each (seconds)', 'Admin option: Overtime', 'yith-auctions-for-woocommerce' ),
			'type'              => 'yith-field',
			'yith-type'         => 'number',
			'class'             => 'ywcact-input-text',
			'desc'              => esc_html__( 'Set how often to automatically refresh the "My Auctions" section', 'yith-auctions-for-woocommerce' ),
			'id'                => 'yith_wcact_settings_live_auction_my_auctions',
			'step' => 1,
			'min'  => 0,
			'default'           => 0,
			'deps'              => array(
				'id'    => 'yith_wcact_ajax_refresh_auction_my_acutions_page',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),

		'settings_ajax_refresh_auction_options_end'        => array(
			'type' => 'sectionend',
			'id'   => 'yith_wcact_settings_regenerate_auction_end',
		),
		// End Ajax Refresh.

		// Auction winner options.
		'settings_auction_winner_options_start'            => array(
			'type' => 'sectionstart',
			'id'   => 'yith_wcact_settings_auction_winner_options_start',
		),

		'settings_auction_winner_options_title'            => array(
			'title' => esc_html_x( 'Auction winner options', 'Panel: page title', 'yith-auctions-for-woocommerce' ),
			'type'  => 'title',
			'desc'  => '',
			'id'    => 'yith_wcact_settings_auction_winner_options_title',
		),
		'settings_auction_winner_redirect_auction_winner'  => array(
			'title'     => esc_html__( 'Within the email notification, redirect the auction\'s winner', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'radio',
			'options'   => array(
				'product'  => esc_html__( 'to auction page', 'yith-auctions-for-woocommerce' ),
				'cart'     => esc_html__( 'to cart page (With auction product in cart)', 'yith-auctions-for-woocommerce' ),
				'checkout' => esc_html__( 'to checkout page', 'yith-auctions-for-woocommerce' ),
			),
			'default'   => 'checkout',
			'desc'      => '',
			'id'        => 'yith_wcact_settings_auction_winner_email_redirect',
			//template auction-winner.php change $url parameter
		),
		'settings_auction_winner_show_label_button'        => array(
			'title'     => esc_html__( 'Button label in email notification', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'text',
			'desc'      => esc_html__( 'Enter the label for the button shown in the email sent to auction\'s winner', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_auction_winner_label_pay_now',
			'default'   => esc_html__( 'Pay now', 'yith-auctions-for-woocommerce' ),
		),
		'settings_auction_winner_show_winner_badge_option' => array(
			'title'     => esc_html__( 'Show winner badge on auction image', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html__( 'Enable to show a winner badge on auction image to the user who won the auction', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_auction_winner_show_winner_badge',
			'default'   => 'no',
		),
		'settings_auction_winner_show_winner_badge_custom' => array(
			'name'      => esc_html_x(
				'Winner badge',
				'Admin option: Winner badge',
				'yith-auctions-for-woocommerce'
			),
			'type'      => 'yith-field',
			'yith-type' => 'upload',
			'id'        => 'yith_wcact_winner_badge_custom',
			'default'	=> YITH_WCACT_ASSETS_URL . 'images/icon/winner-logo.svg',
			'deps'      => array(
				'id'    => 'yith_wcact_auction_winner_show_winner_badge',
				'value' => 'yes',
				'type'  => 'hide',
			),
		),
		'settings_auction_winner_show_winner_message_optional'      => array(
			'title'     => esc_html_x( 'Custom message to the winner', 'Admin option: Custom message to winner.', 'yith-auctions-for-woocommerce' ),
			'type'            => 'yith-field',
			'yith-type'       => 'textarea-editor',
			'desc'      => implode(
				'<br />',
				array(
					esc_html__( 'Enter an optional message to show to the user who won the auction.', 'yith-auctions-for-woocommerce' ),
					esc_html__( 'You can use the following placeholders:', 'yith-auctions-for-woocommerce' ),
					esc_html__( '%username% => Username of maximum bid.', 'yith-auctions-for-woocommerce' ),
					esc_html_x( '%price% => Final price of auction product. ', 'yith-auctions-for-woocommerce' ),
				)
			),
			'wpautop'       => false,
			'id'        => 'yith_wcact_auction_winner_custom_message',
			'default'	=> implode(
				'<br />',
				array(
					esc_html__( 'You won this auction with the final price of %price%', 'yith-auctions-for-woocommerce' ),
					esc_html__( 'Be sure to pay for the product within 3 days to avoid losing it!', 'yith-auctions-for-woocommerce' ),
				)
			),
		),

		'settings_auction_winner_show_button_pay_now'      => array(
			'title'     => esc_html_x( 'Show \'Pay Now\' button in the product page', 'Admin option: Show button pay now in product page', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html_x( 'Check this option to show \'Pay Now\' button in the product when the auction ends', 'Admin option description: Check this option to show \'Pay Now\' button in the product when the auction ends ', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_tab_auction_show_button_pay_now',
			'default'   => 'yes',
		),
		'settings_auction_winner_show_button_add_to_cart_instead_of_pay_now' => array(
			'title'     => esc_html_x( 'Possibility to add auction product with other products ', 'Admin option: Posibility to add to cart auction product', 'yith-auctions-for-woocommerce' ),
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
			'desc'      => esc_html_x( 'Check this option to allow adding auction products and other product types to cart in the same order', 'Admin option description: Check this option to show pay now button in product when the auction ends', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_settings_tab_auction_show_add_to_cart_in_auction_product',
			'default'   => 'no',
		),
		'settings_auction_winner_options_end'              => array(
			'type' => 'sectionend',
			'id'   => 'yith_wcact_settings_auction_winner_options_end',
		),
		// End Auction winner options.

		// Enable Easy Login Popup on auction page

		'settings_login_start'             => array(
			'type' => 'sectionstart',
			'id'   => 'yith_wcact_settings_login_start',
		),

		'settings_login_title'             => array(
			'name' => __( 'Login/register modal', 'yith-auctions-for-woocommerce' ),
			'type' => 'title',
			'desc' => ( ! defined( 'YITH_WELRP') ) ? sprintf( __( 'You need to install our <a href="%s" target="_blank">%2s</a> Plugin. You\'ll be able to enable this option.', 'yith-auctions-for-woocommerce' ), $yith_wceasy_landing, 'YITH Easy Login & Register Popup for WooCommerce' ) : '',
			'id' => 'yith_wcact_settings_allow_register_or_login_title',
		),

		'settings_login_integration' => array(
			'name'      => esc_html__( 'Show a login/register modal', 'yith-auctions-for-woocommerce' ),
			'desc'      => esc_html__( 'Enable this option in order to allow users to login or register directly from auction page without the need to be redirected to my account page', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_enable_login_popup',
			'default'   => 'no',
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
		),

		'settings_login_end'               => array(
			'type' => 'sectionend',
			'id'   => 'yith_wcact_settings_login_end',
		),
		// End Enable Easy Login Popup on auction page

		// Verify payment method of bidders.
		'settings_verify_payment_method_start'             => array(
			'type' => 'sectionstart',
			'id'   => 'yith_wcact_settings_verify_payment_method_start',
		),
		'settings_verify_payment_method_title'             => array(
			'name' => __( 'Verify payment method of bidders', 'yith-auctions-for-woocommerce' ),
			'type' => 'title',
			'desc' => ( ! defined( 'YITH_WCSTRIPE_PREMIUM') ) ? sprintf( __( 'You need to install our <a href="%s" target="_blank">%2s</a> Plugin. You\'ll be able to enable this option.', 'yith-auctions-for-woocommerce' ), $yith_wcstripe_landing, 'YITH WooCommerce Stripe Premium' ) : '',
			'id' => 'yith_wcact_settings_verify_payment_method_title',
		),
		'settings_verify_payment_method_integration' => array(
			'name'      => esc_html__( 'Verify payment method', 'yith-auctions-for-woocommerce' ),
			'desc'      => esc_html__( 'Enable this option to check if a customer has at least one card saved on My account > Payment method section. Without at least one card, the customer will not be able to bid on a product and cannot pay for the product if it has won the auction.', 'yith-auctions-for-woocommerce' ),
			'id'        => 'yith_wcact_verify_payment_method',
			'default'   => 'no',
			'type'      => 'yith-field',
			'yith-type' => 'onoff',
		),

		'settings_verify_payment_method_end'               => array(
			'type' => 'sectionend',
			'id'   => 'yith_wcact_settings_verify_payment_method_end',
		),
		// End Verify payment method of bidders.
		'settings_resend_winner_auction_options_title'    => array(
			'title' => esc_html_x( 'Resend winner email', 'Panel: page title', 'yith-auctions-for-woocommerce' ),
			'type'  => 'title',
			'desc'  => '',
			'id'    => 'yith_wcact_settings_resend_winner_auction_title'
		),
		'settings_resend_winner_auction_options_button' => array(
			'title' => esc_html__( 'Resend winner email', 'yith-auctions-for-woocommerce' ),
			'id'    => 'yith_wcact_settings_resend_winner_auction_button',
			'desc'  => esc_html__( 'Click to resend the email to the winner in case the sending failed', 'yith-auctions-for-woocommerce' ),
			'type'  => 'yith_wcact_html',
			'html'  => '<a class="button" href="'.$resend_winner_email_url.'">'.esc_html__( 'Resend winner email', 'yith-auctions-for-woocommerce' ).'</a>',
		),
		'settings_resend_winner_auction_options_end'      => array(
			'type' => 'sectionend',
			'id'   => 'yith_wcact_settings_resend_winner_auction_end'
		),

	)
);